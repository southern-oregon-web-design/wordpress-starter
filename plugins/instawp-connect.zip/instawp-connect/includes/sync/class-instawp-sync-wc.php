<?php

defined( 'ABSPATH' ) || exit;

class InstaWP_Sync_WC {

    public function __construct() {
        
    }
}
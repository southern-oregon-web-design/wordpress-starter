<?php
/**
 * Start from page template
 */
?>
<div class="jet-form-page <?php echo $hidden_class; ?>" data-page="<?php echo $this->page; ?>">
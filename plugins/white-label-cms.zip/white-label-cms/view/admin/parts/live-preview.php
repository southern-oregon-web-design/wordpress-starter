<div class="lightbox short-animate" id="wlcms-preview-content">
    
</div>
<div id="lightbox-controls" class="short-animate">
    <a id="close-lightbox" class="long-animate" href="#"><?php _e('Close Preview')?></a>
</div>
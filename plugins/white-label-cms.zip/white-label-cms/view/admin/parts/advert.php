<div class="wlcms-advert-wrapper">
	<a href="https://www.videousermanuals.com/a-better-wp-for-clients" target="_blank">
		<picture>
			<source srcset="<?php echo WLCMS_ASSETS_URL ?>images/better-wp-clients-m.jpg" media="(max-width: 480px)">
			<img srcset="<?php echo WLCMS_ASSETS_URL ?>images/better-wp-clients.jpg" alt="A Better WordPress for Clients">
		</picture>
	</a>
</div>
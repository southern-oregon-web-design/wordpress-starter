<div class="wlcms-input-group">
    <div class="wlcms-input">
        <textarea class="textarea-full" name="settings_custom_css_admin"><?php echo esc_html(wlcms_field_setting('settings_custom_css_admin')) ?></textarea>
    </div>
    <div class="wlcms-help"><?php _e('Override or add to any of the styles in the WordPress admin enter your own custom css here', 'white-label-cms') ?></div>
</div>
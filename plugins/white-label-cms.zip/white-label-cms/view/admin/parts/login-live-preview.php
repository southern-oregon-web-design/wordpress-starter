<div class="lightbox short-animate" id="wlcms-login">
    
</div>
<div id="lightbox-controls" class="short-animate">
    <a id="close-lightbox" class="long-animate" href="#login"><?php _e('Close Login')?></a>
</div>
<?php
if (!defined('ABSPATH')) {
    die('Access denied.');
}
=== WP Umbrella: Manage Multiple Sites - Ideal For WordPress Maintenance ===
Contributors: gmulti, truchot
Tags: Manage multiple sites, maintenance, backup, monitoring, update
Requires at least: 5.8
Tested up to: 6.3
Requires PHP: 7.2
Stable tag: v2.11.6
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Everything agencies and freelancers need to sell WordPress maintenance and manage multiple sites effortlessly.

== Description ==

WP Umbrella gives you everything you need to manage multiple WordPress sites effortlessly. WP Umbrella is Helping Agencies and Freelancers with their WordPress maintenance business.

WP Umbrella includes powerful features that make multiple WordPress websites management a breeze.Our core features include:
* Dashboard to manage, update and backup all your sites.
* Automatic backups stored in the cloud.
* Update all your sites in 1-click.
* WordPress monitoring (PHP errors, uptime, performance and GooglePage).
* Automated maintenance reports to prove the value of your WordPress maintenance service to your clients.

WP Umbrella is the best alternative to ManageWP, MainWP, WP Remote and InfiniteWP.

= Manage multiple sites from a single dashboard =
WP Umbrella compiles the data from all of your sites on one dashboard, so you can check up on your websites in a single glance and log in your WordPress admin in 1-click.

= Update Manager =
Safely update all your plugins, themes and WordPress in just 1-click and save a ton of time. Updating multiple sites has never been so easy.

= Automatically Backup WordPress =

Backup and restore all your websites in just 1-click from WP the dashboard. Backups are incremental, stored in the cloud and GDPR compliant.

= WordPress Monitoring =

The most comprehensive monitoring solution for WordPress: monitor uptime, downtime, GooglePage Speed and PHP Errors and be alerted in case of issues.

= Maintenance Reports =

Prove the value of your WordPress maintenance to your clients with white-label automated maintenance reports. Google Analytics integration included.

= Premium / Freemium =

Create an account and enjoy 14 day trial with all features (backup, uptime monitoring, etc). Then you only have access to our health check and safe update technology.

== Installation ==

= Minimum Requirements for WP Umbrella =
* WordPress 5.8 or greater
* PHP version 7.2 or greater

== Frequently Asked Questions ==

= Why do I need WP Umbrella ? =

WP Umbrella gives you everything you need to manage hundreds of WordPress sites effortlessly.
* Save a ton of time with multiple WordPress sites management and update
* Find peace of mind with a reliable all-in-one solution to manage update monitor and backup your sites.
* Improve communication with your existing clients about WordPress maintenance benefits

= Is WordPress maintenance needed? =

WordPress sites need routine maintenance and updates to ensure it performs optimally. This may require to regularly update and backup your websites.

= Everything you need to know about backup =

All our backups are stored in Europe on Google Cloud servers and are GDPR compliant. Automatic backups can be make every hour. Automatic backups are stored during 50 days. Automatic backups are incremental. You can make up manual backup. Manual backups are stored during 14 days.

= How can I bulk update WordPress ? =

WP Umbrella offers an easy update manager that allows you to update all your plugins, on all your websites in just one-click. You can also disable update or enable automatic updates.

= What do you monitor? =

WP Umbrella is a comprehensive WordPress management and monitoring tool. Curious about it? Read our guide about [WordPress monitoring!](https://wp-umbrella.com/blog/monitoring-wordpress-the-ultimate-guide/)

= How can I manage multiple WordPress sites? =

We suggest you to read our guide about [How to manage multiple WordPress sites easily](https://wp-umbrella.com/blog/manage-multiple-wordpress-sites-one-dashboard/)

= Does WP Umbrella work with multisite ? =

Yes, multisite networks are fully supported, including the ability to backup and update a multisite network.

= How are you better than ManageWP? =

WP Umbrella is easier to use and faster than managewp.

== Changelog ==

= 2.11.6 (10-20-2023) =
- Fix: Deprecated dynamic property on PHP 8.2
- Fix: Drop table instruction on backup
- Improved: amelia compatibility for database backup
- Removed: old restore script

= 2.11.5 (10-05-2023) =
- Fix: directory empty during backup

= 2.11.4 (10-05-2023) =
- Improved: “IGNORE” instruction to the database backup script to prevent key duplication errors.
- Improved: backstits to the query to retrieve row size
- Improved: compatibility with Bedrock for backup
- Fix: Correction of WordPress theme names that are sometimes the wrong ones.
- Fix: division by zero during backup

= 2.11.3 (09-12-2023) =
- Fix: Auto install API Key
- Improved: reduce default batch for big table

= 2.11.2 (08-15-2023) =
- Fix: automatic data retrieval for restoration
- Improved: Add filter for reduce table batch size on big table
- Improved: Compatibility with WPML custom table

= 2.11.1 (07-09-2023) =
- Improved: Compatibility with GridPane
- Fix: Snapshot data with an ajax call

= 2.11.0 (07-06-2023) =
- Security Fix: Store secret token api hashed
- Improved: Cache compatibility with Nitropack
- Improved: Improved plugin loading
- Improved: 1 click access to the admin of a site
- Fix: White label data on update-core.php


Our full changelog can be accessed [Here!](https://wp-umbrella.com/change-log/)

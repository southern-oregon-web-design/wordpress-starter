<?php

namespace WPUmbrella\DataTransferObject;

if (!defined('ABSPATH')) {
    exit;
}

class User
{
}

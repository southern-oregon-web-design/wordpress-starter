<?php

namespace WPUmbrella\Core\Exceptions;

class BackupNotCreated extends \Exception
{
}

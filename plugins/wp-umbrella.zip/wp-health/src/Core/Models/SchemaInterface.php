<?php
namespace WPUmbrella\Core\Models;

interface SchemaInterface
{
	public function getSchema($options);
}

<?php
namespace WPUmbrella\Core\Models\Memento;


interface Memento
{
    public function getName();

    public function getDate();
}

<?php

namespace WPUmbrella\Models\Table;

interface TableStructureInterface {


    /**
     * @return array
     */
	public function getColumns();

}

<?php

namespace WPUmbrella\Models\Backup;


interface BackupProcessCommandLine
{
	public function getCommandLine();
}

<?php

namespace WPUmbrella\Models\Backup;

interface BackupNamer
{
	public function getName();
}

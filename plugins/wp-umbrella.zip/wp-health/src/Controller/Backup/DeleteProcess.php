<?php
namespace WPUmbrella\Controller\Backup;

use WPUmbrella\Core\Models\AbstractController;

class DeleteProcess extends AbstractController
{
    public function executeDelete($params)
    {
		$version = isset($_GET['version']) ? $_GET['version'] : 'v1';

		if($version === 'v1'){
			$manageProcess = wp_umbrella_get_service('BackupManageProcess');
		}
		else if($version === 'v3'){
			$manageProcess = wp_umbrella_get_service('BackupManageProcessCustomTable');
		}

		$manageProcess->unscheduledBatch();

        return $this->returnResponse(['code' => 'success', 'message' => 'Backup unscheduled']);
    }
}

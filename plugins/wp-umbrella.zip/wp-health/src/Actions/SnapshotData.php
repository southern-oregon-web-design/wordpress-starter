<?php
namespace WPUmbrella\Actions;


use WPUmbrella\Core\Hooks\ExecuteHooks;
use WPUmbrella\Core\Hooks\DeactivationHook;


/**
 * @deprecated
 */
class SnapshotData implements ExecuteHooks, DeactivationHook
{
    public function hooks()
    {
        add_action('admin_init', [$this, 'init']);
    }

    public function init()
    {
        if (!function_exists('as_schedule_recurring_action')) {
            return;
        }

		if(!function_exists('as_has_scheduled_action')){
			return;
		}

		if(!as_has_scheduled_action('wp_umbrella_snapshot_data')){
			return;
		}

		as_unschedule_action('wp_umbrella_snapshot_data');
    }

    public function deactivate()
    {
		as_unschedule_action('wp_umbrella_snapshot_data');
    }
}

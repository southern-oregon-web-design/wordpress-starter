<?php

namespace WPUmbrella\Helpers;

if (!defined('ABSPATH')) {
    exit;
}

abstract class Pages
{
    const SETTINGS = 'wp-umbrella-settings';
}
